#!/bin/bash

vivado -mode batch -source name_of_script.tcl
